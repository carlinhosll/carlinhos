// Interações simples
const menuBtn = document.querySelector('.menu-btn');
const menu = document.getElementById('menu');
if (menuBtn) {
  menuBtn.addEventListener('click', () => {
    const open = menu.classList.toggle('show');
    menuBtn.setAttribute('aria-expanded', String(open));
  });
}

// Data de build
document.getElementById('build-date').textContent = new Date().toLocaleDateString('pt-BR');

// Galeria automática: carrega todas as imagens da pasta /assets/galeria com nomes img-1.webp...img-6.webp
(function renderGaleria() {
  const root = document.getElementById('galeria-grid');
  if (!root) return;
  const max = 6;
  for (let i = 1; i <= max; i++) {
    const img = document.createElement('img');
    img.loading = 'lazy';
    img.alt = 'Imagem de galeria ' + i;
    img.src = `assets/galeria/img-${i}.webp`;
    img.onerror = () => img.remove();
    root.appendChild(img);
  }
})();
