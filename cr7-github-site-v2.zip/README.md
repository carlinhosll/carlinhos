# Fã Site Cristiano Ronaldo (para GitHub Pages)

Site estático simples e responsivo para publicar no **GitHub Pages**.
Feito como demonstração educacional. Substitua textos e imagens por conteúdo seu.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub (ex.: `cr7-site`).
2. Envie estes arquivos para o repositório (arraste e solte pela interface web ou use Git).
3. Vá em **Settings → Pages**.
   - Em **Build and deployment**, selecione **Deploy from a branch**.
   - Escolha a branch **main** e o diretório **/** (root).
   - Salve.
4. Aguarde a publicação. O seu site aparecerá em uma URL parecida com `https://seu-usuario.github.io/cr7-site`.

## Personalização
- **Textos**: edite `index.html`.
- **Cores**: ajuste variáveis no topo de `styles.css`.
- **Números**: atualize a seção “Números” em `index.html`.
- **Imagens**: troque os arquivos da pasta `assets/`. Use **somente imagens com direitos de uso**.
  - `assets/hero-placeholder.webp` → troque por `hero.webp` (mesma dimensão sugerida).
  - Galeria: adicione até 6 imagens como `assets/galeria/img-1.webp` … `img-6.webp`.
- **Vídeo**: em `index.html`, substitua o `src` do iframe por um vídeo oficial do YouTube.

## Licenças e direitos
- Este é um **site de fã, não oficial** e **sem fins comerciais**.
- Use apenas conteúdo (fotos, vídeos e logos) do qual você tenha permissão de uso.

## Desenvolvimento
- HTML, CSS e JS puros, sem dependências.
- Acessível e responsivo, com design leve.
- Compatível com GitHub Pages.

---

Gerado em 22/08/2025.
